<?php
#Enviar en post que html se necesita para que aparezca en el modal "pop-up"
$tipoPost = $_POST['data'];
if (isset($_POST['data'])) {
	switch ($tipoPost) {
		case '1':
			?>
			<img src="assets/img/sectur/constancia.jpg" style="max-width:100%; max-height:400px;margin: 0 auto;" class="center-block">
			<?php
			break;
		case '2':
			?>
			<div class='row' style='max-height:400px;'>
								<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<p><strong>NOSOTROS</strong></p>
								<p class='text-justify'>Somos una empresa que está dedicada a proporcionar el servicio e instalaciones de la
								más alta calidad a nuestros clientes y ser líder en el mercado de los segmentos de lujo y
								alto poder adquisitivo de la industria de la propiedad vacacional en México, oeste de los
								Estados Unidos y oeste de Canadá. Proporcionar servicios de la más alta calidad para la
								organización de sus vacaciones, considerando a la vez los requerimientos particulares de
								nuestros clientes.</p>
								<p><strong>Club Vacacional</strong></p>
								<p class='text-justify'>El club vacacional es una experiencia puramente vacacional, respaldada por hoteles
								manejados por grandes cadenas hoteleras de todo el mundo.
								No somos tiempo compartido, manejamos un club vacacional. ¿Cuál es la diferencia? El
								tiempo compartido es la noción de una segunda casa compartida con una serie de gentes
								que tienen las demás semanas del año. Desde sus inicios opera con unidades habilitadas
								con cocinas, lavadoras y todo ese tipo de cosas que le hacen parecer una segunda casa
								pero fraccionada.
								El club vacacional, en cambio, es una experiencia puramente vacacional, no va usted a
								cocinar, no va a un departamento en sí, sino que en la mayoría de los casos va usted a
								hoteles manejados por grandes cadenas hoteleras. El club opera a base de créditos
								vacacionales, donde puede elegir destinos diferentes en todo el mundo. Al formar parte
								de nosotros usted podrá organizar sus vacaciones para satisfacer todas.</p>
								</div>
								</div>

			<?php
			break;
		case '3':
			?>
			<div class='row' style='max-height:400px;'>
								<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<p><strong>Terminos y Condiciones</strong></p>
								<p class='text-justify'>
								<ol>
								<li>Nuestros paquetes vacacionales son desde 5 días y 4 noches en  PLAN TODO
								INCLUIDO o PLAN EUROPEO.Todo incluido es un término hotelero que incluye TODOS
								los alimentos y bebidas ilimitadas durante su hospedaje. Plan Europeo es solamente
								alojamiento.</li>
								<li>Nuestros paquetes al ser un beneficio directo del Hotel, NO INCLUYEN VUELOS. </li>
								<li>Su reservacion deberá ser solicitada vía telefónica, por favor asegúrese de tener a la
								mano su número de tarjeta y código de promoción.</li>
								<li>Todas las Noches, adultos, niños y habitaciones adicionales pueden estar disponibles a
								precios preferenciales, estas se pagan una vez que el hotel confirme su estadía, las
								mismas están sujetas a disponibilidad, no tomándose en cuenta el precio por noche de la
								presente promoción.</li>
								<li>No se harán reembolsos por noches no utilizadas, incluyendo aquellas que resulten de
								llegadas tardías o salidas tempranas.</li>
								<li>Los huéspedes deben tener para el check in por lo menos 21años de edad a la fecha

								de su llegada o deben estar acompañados por sus padres o un adulto.</li>
								<li>El cliente entiende que por el precio en promoción es con el fin de presentarle un
								programa vacacional al siguiente día de haber ingresado al hotel o durante su estancia.  El
								cliente debe asistir con su cónyuge a la presentación del Club Vacacional que patrocina
								este paquete vacacional, con duración mínima de 90 MINUTOS.</li>
								<li>NO APLICA PARA EMPLEADOS Y FAMILIARES DE LA INDUSTRIA TURISTICA,
								HOTELEROS, DESEMPLEADOS O AGENCIAS DE VIAJES.</li>
								<li>Toda reservación está sujeta a disponibilidad. Tiene una vigencia de 12 meses a partir
								de la fecha de compra. Las Reservaciones se hacen con 60 días de anticipación para
								temporadas altas y 45 días para temporadas bajas como mínimo y por escrito
								a: info@vacationescancunrivieramaya.com  para garantizar el buen servicio y alojamiento.
								Nos se reservamos la facultad de cambiar hotel sede por otro de igual o mejor calidad en
								el mismo destino a discreción.</li>
								<li>NO APLICA SEMANA SANTA, PASCUA, NAVIDAD NI AÑO NUEVO a menos que el
								hotel lo permita y cubriendo una cuota adicional por ésta temporada.</li>
								<li>No hay cancelaciones ni reembolsos ya que se trata de un paquete promocional.
								Cambios de fecha sólo por escrito a: info@vacationescancunrivieramaya.com y con un
								mínimo de 30 días antes de su fecha de llegada. Todo cambio tiene un costo, favor de
								consultarlo con su Asesor Vacacional. UNA VEZ TENIENDO NUMERO DE
								CONFIRMACION, SI NO SE PRESENTA EN LAS FECHAS SOLICITADAS SE HARA UN
								CARGO DE $500 DOLARES AL TIPO DE CAMBIO DE ESE DIA.</li>
								<li>Los formatos de Términos y Condiciones deberán ser firmados en un lapso no mayor
								a 48 horas para respetar los beneficios antes mencionados ya que con la carta de
								aceptación se emite su confirmación oficial con el hotel. Existen términos y condiciones
								específicos por cada prestador de servicio participante.</li>
								<li>Vacaciones Cancun y Riviera Maya y sus representantes actúan como terceros en
								cuanto a los servicios ofrecidos en esta promoción por lo que el cliente los deslinda de
								cualquier responsabilidad que pudiera surgir de: HOSPEDAJE, SOBREVENTA,
								ALIMENTOS O BEBIDAS ó TRASLADOS TERRESTRES.</li>
								<li>En caso de no asistir a la presentación del Club Vacacional o de no cumplir con los
								requisitos ya acordados en la carta de términos y condiciones el día de la presentación, el
								cliente entiende que el descuento y promoción se anulan y acepta pagar al patrocinador la
								cantidad de la tarifa regular que este en el momento del registro por la cantidad de noches
								y personas reservadas.</li>
								<li>El proveedor del servicio no es responsable por ningún acuerdo verbal o compromiso
								entre el cliente y los representantes de ventas, al menos que dichos compromisos se
								encuentren contenidos por escrito dentro del contrato o licencia de usuario final.</li>
								<li>SI amigos o familiares están viajando juntos con diferente número de confirmación,
								sólo UNO aplicará para esta promoción y las segundas, terceras o cuartas deberán pagará
								Tarifa Rack.</li>
								<li>La agencia NO VENDE VUELOS por tanto no se hace responsable de la compra
								anticipada ó retardada de estos por parte del cliente.</li>
								<li>Horario de atención lunes a viernes de 9 a.m. a 6 p.m. y sábados de 10 a.m. a 2 p.m.</li>
								<li>El prestador de servicio no es responsable por actos de la naturaleza que pudieran
								causar inconvenientes a los clientes, en caso de desastres naturales o terrorismo o de
								cualquier otra índole fuera de nuestro control, el prestador no tendrá ninguna
								responsabilidad y no tendrá que efectuar ningún tipo de reembolso por ninguna de estas
								razones.</li>
								</ol>
								</p>
								</div>
								</div>
			<?php
			break;
		case '4':
			?>
			<div class='row' style='max-height:400px;'>
								<div class='col-lg-12 col-md-12 col-sm-12 col-xs-12'>
								<p><strong>Aviso de Privacidad de Datos</strong></p>
								<p class='text-justify'>
								Mira Travel, S.A. de C.V. y / o cualquiera de sus filiales o subsidiarias establece que
								información personal que pueda llegar a recoger, es con el fin de prestar los servicios o
								productos que vende y para fines de identificación, respetando lo establecido en la Ley
								Federal de Protección de Datos de la posesión personal de los individuos.

								Para cualquier pregunta relacionada con sus datos personales, puede hacerlo haciendo
								referencia a la página <a href='http://www.vacacionescancunrivieramaya.com'>www.vacacionescancunrivieramaya.com</a> privacidad o por e- mail
								a <a href='mailto:info@vacacionescancunrivieramaya.com'>info@vacacionescancunrivieramaya.com</a>. Cualquier cambio a éste aviso de privacidad
								aparecen en el sitio web antes mencionado.

								Por lo tanto, a través del programa de privacidad para los clientes de la comercialización
								de Mira Travel, S.A. de C.V., su privacidad está en buenas manos.

								Como cliente de la comercialización de Mira Travel, S.A. de C.V. o cualquiera de sus
								sociedades o filiales, tienes la oportunidad de elegir los productos y servicios que
								ofrecemos, a sabiendas de que sus datos personales están protegidos.

								La seguridad de su información personal es nuestra prioridad, por eso protegemos esta
								información mediante el mantenimiento de protecciones físicas, electrónicas y de
								procedimiento la formación de nuestros empleados en el manejo adecuado de su
								información personal con el fin de evitar que personas no autorizadas accedan a la misma.

								Además de lo anterior, el 5 de julio de 2010 se publicó en el Diario Oficial de la Ley Federal
								de Protección de Datos Personales en Posesión de los individuos (en adelante, la “Ley”),
								las disposiciones contribuyen claramente a nuestro objetivo de proteger sus datos
								personales. Puede acceder al contenido de la ley a través de los portales al Gobierno
								Federal, a través de la Secretaría de Gobernación y de la Cámara de Diputados del
								Congreso cuyas direcciones
								son:<a href="http://www.ordenjuridico.gob.mx" target="_blank">www.ordenjuridico.gob.mx</a> y <a href="http://www.diputados.gob.mx" target="_blank">www.diputados.gob.mx</a>

								En virtud de lo anterior, tenga en cuenta que de acuerdo con nuestro programa de
								privacidad y la Ley, los datos personales recogidos en virtud de las transacciones que
								usted solicite o realizados con la comercialización Vacaciones Cancun y Riviera Maya
								serán tratados de forma confidencial a través de los sistemas previstos para tales fines.
								</p>

								<p><strong>RESPONSABLES DE PROCESAMIENTO DE DATOS PERSONALES:</strong></p>
								<p>
								El controlador de sus datos personales será de una sola entidad, se hace referencia en el
								primer párrafo de esta nota, que busca satisfacer su demanda de un producto, o para
								formalizar la conclusión de cualquier producto.
								</p>

								<p><strong>Mira Travel, S.A. de C.V.</strong></p>

								<p>Dirección: Para efectos de éste aviso de privacidad, Mira Travel, S.A. de C.V.  identifica
								su oficina ubicada en:
								Av. Bonampak No. 28,  en la ciudad de Cancún, Estado de Quintana Roo, C.P.77500 (ver
								mapa de localización).</p>

								<p><strong>Los datos personales que se puede recoger:</strong></p>

								<p>Mira Travel, S.A. de C.V. recogerá los datos personales necesarios para la formalización
								del tipo de turismo o producto financiero que usted solicita o requiere , entre otros, pero no
								limitado a Vacaciones Cancun y Riviera Maya puede recopilar su nombre, dirección, fecha
								de nacimiento, país de nacimiento, nacionalidad, ocupación, profesión, actividad o tipo de
								negocio que se dedica, números de teléfono, NIF Federal, así como la tarjeta de crédito o
								pagos con tarjeta de débito en línea o por teléfono por nuestro departamento de servicio al
								cliente solamente. Además, para nuestra línea de crédito interno, Marf Travel Vacation
								está obligada a requerir datos adicionales que permite estimar la viabilidad de pago,
								utilizando un análisis basado en cuantitativos y cualitativos, para establecer su solvencia y
								capacidad de pago.</p>

								<p><strong>Finalidad del tratamiento de datos personales:</strong></p>

								<p>Los datos personales recogidos por Vacaciones Cancun y Riviera Maya se utilizarán para
								la operación y registro de los productos que usted ha contratado, así como para
								proporcionar, en su caso, otros productos turísticos de la comercialización de Mira Travel,
								S.A. de C.V.  o cualquiera de sus filiales, así como enviar promociones de otros bienes o
								servicios relacionados con el turismo o los productos financieros mencionados.</p>

								<p><strong>Transferencia de datos personales:</strong></p>

								<p>Mira Travel, S.A. de C.V. podrá transferir sus datos personales a terceros mexicanos o
								extranjeros que prestan servicios necesarios para su buen funcionamiento y sus afiliados.
								En tales casos, debe tenerse presente que Mira Travel, S.A. de C.V. tomará las medidas
								necesarias para que las personas que tienen acceso a información personal cumplir con la
								política de privacidad de Mira Travel, S.A. de C.V. y los principios de protección de datos
								establecidos por la ley.</p>

								<p><strong>Derechos ARCO: (Acceso, Rectificación, Cancelación, Oposición).</strong></p>

								<p>Usted o su representante legal autorizado pueden limitar el uso o divulgación de sus datos
								personales, también de 06 de enero 2012 podrá ejercer, en su caso, los derechos de
								acceso, rectificación, cancelación u oposición a la Ley proporciona a petición presentada a
								la dirección anterior de Mira Travel, S.A. de C.V.. y es importante tener en cuenta que el
								ejercicio de ese derecho no es un requisito previo, ni impide el ejercicio de otro derecho.
								Asimismo, le informamos que usted tiene derecho a iniciar un procedimiento ante el
								Instituto Federal de Protección de Datos de Acceso a la Información y Protección de Datos
								(<a href="http://www.ifai.gob.mx" target="_blank">www.ifai.gob.mx</a>) dentro de los 15 días siguientes a la fecha en que se recibió una
								respuesta de la comercialización de Mira Travel, S.A. de C.V. dentro de los 20 días de la
								recepción de su solicitud para ejercer el derecho.</p>

								<p><strong>Modificaciones al aviso de privacidad:</strong></p>

								<p>Cualquier enmienda a este aviso se le notificará a través de cualquiera de los siguientes
								medios: un mensaje enviado a su dirección de e -mail o teléfono, un mensaje difundido a
								través de <a href="http://www.vacacionescancunrivieramaya.com">www.vacacionescancunrivieramaya.com</a> o cualquier medio electrónico que se
								utilizan para ponerse en contacto con Mira Travel, S.A. de C.V. gerencia.</p>
								</div>
			<?php
			break;

		case 'omni':
			?>
			<div class='row' style='max-height:400px;'>
								<div class="col-md-6 col-md-6 col-sm-6 col-xs-12">
								<span><strong>Omni Cancun Hotel & Villas</strong></span>
								<p>
								Omni Cancún Hotel & Villas es el destino perfecto en México, donde podrás disfrutar de un largo fin de semana en nuestras lujosas
								instalaciones o unas largas vacaciones en una villa de alquiler. El todo incluido Omni Cancún Hotel es un "Gran turismo" resort de
								cinco estrellas, situado entre el deslumbrante Caribe Mexicano y la aislada Laguna Nichupté en Cancún. Las habitaciones y villas
								que rodean con el espíritu y tradición de la cultura maya al tiempo que ofrece todas las comodidades del hotel. Amplias playas de
								aguas cristalinas, majestuosas puestas de sol en la laguna, espectaculares vistas al mar y un servicio sin igual hacen del Omni
								Cancún Hotel & Villas la elección perfecta para su escapada hacia Cancún, México.
								</p>
								</div>
								<div class="col-md-4 col-md-4 col-sm-4 col-xs-12">
								<img src="assets/img/hoteles/omni.jpg" style="width:400px;">
								</div>
								</div>
			<?php
			break;
		case 'sandos':
			?>
			<div class='row' style='max-height:400px;'>
								<div class="col-md-6 col-md-6 col-sm-6 col-xs-12">
								<span><strong>SANDOS PLAYACAR BEACH RESORT</strong></span>
								<p>La animada ciudad de Playa del Carmen te ofrece increíble belleza natural para tus vacaciones en México; aquí los vacacionistas
								pueden escapar a un mundo de playas de arena blanca y aventuras en la selva sobre la costa del precioso Mar Caribe. Sandos Playacar
								 Beach Resort se encuentra en una de las playas más grandes y hermosas de toda la región en la exclusiva zona de Playacar, y por
								 lo tanto es una de las mejores opciones entre los hoteles en Playa del Carmen. Esta experiencia Todo Incluido en México incluye
								 una lista interminable de restaurantes por elegir, además de clubs diseñados para los bebés, los niños y los adolescentes.
								 El entretenimiento de este hotel ofrece diversión para todos durante el día y la noche, y también contamos con campo de minigolf,
								 área de hidroterapia y renta gratuita de bicicletas. Cuando eliges hospedarte en la sección Select Club Adults Only,
								 tendrás acceso a servicios adicionales como un área exclusiva de piscina y jacuzzi, el Select Club lounge y un desayuno buffet
								 especial, todo para los adultos de 18+ años.</p>
								</div>
								<div class="col-md-4 col-md-4 col-sm-4 col-xs-12">
								<img src="assets/img/hoteles/sandosplayacar.jpg" style="width:400px;">
								</div>
								</div>
			<?php
			break;
		case 'caracol':
			?>
			<div class='row' style='max-height:400px;'>
								<div class="col-md-6 col-md-6 col-sm-6 col-xs-12">
								<span><strong>SANDOS CARACOL ECO RESORT</strong></span>
								<p class="text-justify">
								Escapa a este hermoso hotel Todo Incluido en Playa del Carmen, donde descubrirás exuberante selva, una playa de arena blanca llena
								e palmeras, fauna indígena que vive libremente en nuestra propiedad, y un sinfín de actividades para parejas y familias durante tus
								próximas vacaciones en México. Sandos Caracol Eco Resort ofrece a los vacacionistas el lugar ideal para vivir la belleza natural del
								 Caribe combinada con la fascinante cultura maya a lo largo de unas increíbles vacaciones en Playa del Carmen que jamás olvidarás.
								 quí encontrarás numerosos restaurantes, una piscina principal con mucha diversión, una piscina más tranquila para pura relajación,
								 a exclusiva sección Select Club Adults Only con su propia piscina y restaurante sólo para adultos, un parque acuático especialmente
								 para los niños, eco tours por el manglar y la selva, espectáculos mayas y muchas sorpresas más.
								</p>
								</div>
								<div class="col-md-4 col-md-4 col-sm-4 col-xs-12">
								<img src="assets/img/hoteles/sandoscaracol.jpg" style="width:400px;">
								</div>
								</div>
			<?php
			break;
		case 'reef':
			?>
			<div class='row' style='max-height:400px;'>
								<div class="col-md-6 col-md-6 col-sm-6 col-xs-6">
								<span><strong>THE REEF PLAYACAR RESORT</strong></span>
								<p>
								Ubicado en el corazón de la Riviera Maya en la costa del Caribe bañada por el sol de México, The Reef Playacar Resort & Spa se lleva
								 a una página del libro de jugadas de los antiguos dioses mayas. Por arte de magia que mezcla la tranquilidad de un bosque tropical
								 con la belleza al rojo vivo de una de las playas más espectaculares del mundo, este complejo de lujo frente al mar cautiva familias
								 amantes de la diversión y al mismo tiempo que atienden a las parejas que buscan la soledad.
								</p>
								</div>
								<div class="col-md-4 col-md-4 col-sm-4 col-xs-4">
								<img src="assets/img/hoteles/reefplayacar.jpg" style="width:400px;">
								</div>
								</div>
			<?php
			break;
	}
}
?>
