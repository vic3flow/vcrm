﻿<?php
if(isset($_POST['data'])){
	
	$values = array();
	parse_str($_POST['data'], $values);
	extract($values);
	$tempTel = preg_replace("/[^0-9]/","",$telefono);

	if (!filter_var($email, FILTER_SANITIZE_EMAIL)) {
		echo '<div class="bg-warning"><h2>Proporcione un correo válido</h2></div>';
	}
	elseif (strlen($tempTel) < 7) {
		echo '<div class="bg-warning"><h2>Proporcione un numero válido</h2></div>';
	}
	else{
		require 'assets/libs/phpmailer/PHPMailerAutoload.php';
		$mail = new PHPMailer;
		$mail->isSMTP();                                      // Set mailer to use SMTP
		$mail->Host = 'just43.justhost.com';  // Specify main and backup SMTP servers
		//$mail->SMTPDebug = 1;

		$mail->SMTPAuth = true;                               // Enable SMTP authentication
		$mail->Username = 'info@vacacionescancunrivieramaya.com';                 // SMTP username
		$mail->Password = 'V@cationJD_2015';                           // SMTP password
		$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
		$mail->Port = 26;

		$mail->From = "$email";
		$mail->FromName = $nombre;
		$mail->addAddress('info@vacacionescancunrivieramaya.com');     // Add a recipient
		$mail->Subject = 'Vacacionescancunrivieramaya';

		$mail->isHTML(true);

		$mail->Body = utf8_decode("Teléfono: $telefono");
		$mail->Body .= utf8_decode("<pre>E-Mail: $email");
		$mail->Body .= utf8_decode("<pre>Ciudad: $ciudad");
		if($comentarios != "")
		$mail->Body .= utf8_decode("<pre>Comentarios: $comentarios");
		if(!$mail->send()) {
			echo '<div class="bg-warning"><h2>A ocurrido un error, inténtelo nuevamente.</h2></div>';
		} else {
			echo '<div class="bg-info" style="width:50px;"><h2>Información enviada, gracias.</h2></div>';
		}
	}
}
?>
